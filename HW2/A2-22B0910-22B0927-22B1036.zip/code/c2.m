m = 32;
patch_size = 8;
lambda = 1.0;
frame_size = 256;

tic;

solve_c("barbara256.png", m, patch_size, frame_size, lambda, "images/barbara256_recon_c2.png");
solve_c("goldhill.png", m, patch_size, frame_size, lambda, "images/goldhill_recon_c2.png");

toc;

function solve_c(path, m, patch_size, frame_size, lambda, save_path)
  phi = randn(m,patch_size*patch_size);
  psi = kron(dctmtx(patch_size)',dctmtx(patch_size)');
  A = phi * psi;

  X = double(imread(path));
  X = X(1:frame_size, 1:frame_size);

  X_recon = zeros(size(X));
  X_patches = im2col(X, [patch_size, patch_size]);

  patch_recon_count = zeros(size(X_recon));
  [~,num_patches] = size(X_patches);
  Y = phi * X_patches;

  X_patches_recon = psi * fista(Y,A,lambda);

  for patch_idx = 1:num_patches
    patch = X_patches_recon(:,patch_idx);
    patch = reshape(patch, [patch_size, patch_size]);
    
    row = mod(patch_idx-1, size(X,1)-patch_size+1)+1;
    col = floor((patch_idx-1) / (size(X,1)-patch_size+1))+1;

    X_recon(row:(row+patch_size-1), col:(col+patch_size-1)) = X_recon(row:(row+patch_size-1), col:(col+patch_size-1)) + patch;
    patch_recon_count(row:(row+patch_size-1), col:(col+patch_size-1)) = patch_recon_count(row:(row+patch_size-1), col:(col+patch_size-1)) + 1;
  end

  X_recon = X_recon ./ patch_recon_count;
  X_recon = 255 * (X_recon - min(X_recon, [], "all")) / (max(X_recon, [], "all") - min(X_recon, [], "all"));

  RMSE = norm(X(:) - X_recon(:)) / norm(X(:));
  disp(sprintf("RMSE: %.6f", RMSE));

  X_recon = X_recon / 255;
  figure,imshow(X_recon, []);
  saveas(gcf, save_path);
end

function theta = fista(y, A, lambda)
  theta = zeros(size(A, 2), size(y, 2));
  alpha = eigs(A' * A, 1);
  t = 1;
  theta_prev = theta;

  prev_norm = 0;
  current_norm = norm(y - A*theta, "fro");
  
  while (abs(prev_norm - current_norm) > 0.001)
    prev_norm = norm(y - A*theta, "fro");
    theta_grad = theta + (A'/alpha) * (y - A * theta);
    theta_next = wthresh(theta_grad, "s", lambda / (2 * alpha));
    
    t_next = (1 + sqrt(1 + 4 * t^2)) / 2;
    theta = theta_next + ((t - 1) / t_next) * (theta_next - theta_prev);
    
    theta_prev = theta_next;
    t = t_next;
    current_norm = norm(y - A*theta, "fro");
  end
end
